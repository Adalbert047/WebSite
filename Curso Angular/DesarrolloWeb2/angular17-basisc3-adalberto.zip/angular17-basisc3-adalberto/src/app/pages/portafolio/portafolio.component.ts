import { Component } from '@angular/core';

@Component({
  selector: 'app-portafolio',
  standalone: true,
  imports: [],
  templateUrl: './portafolio.component.html',
  styleUrl: './portafolio.component.css'
})
export class PortafolioComponent {

}
