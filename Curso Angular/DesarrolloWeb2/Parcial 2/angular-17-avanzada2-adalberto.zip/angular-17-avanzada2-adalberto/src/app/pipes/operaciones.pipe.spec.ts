import { OperacionesPipe } from './operaciones.pipe';

describe('OperacionesPipe', () => {
  it('create an instance', () => {
    const pipe = new OperacionesPipe();
    expect(pipe).toBeTruthy();
  });
});
