import { Component } from '@angular/core';

@Component({
  selector: 'app-dancing',
  standalone: true,
  imports: [],
  templateUrl: './dancing.component.html',
  styleUrl: './dancing.component.css'
})
export class DancingComponent {

}
