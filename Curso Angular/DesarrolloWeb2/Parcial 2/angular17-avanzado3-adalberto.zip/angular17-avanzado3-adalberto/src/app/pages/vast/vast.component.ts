import { Component } from '@angular/core';

@Component({
  selector: 'app-vast',
  standalone: true,
  imports: [],
  templateUrl: './vast.component.html',
  styleUrl: './vast.component.css'
})
export class VastComponent {

}
