import { Component } from '@angular/core';

@Component({
  selector: 'app-jersey',
  standalone: true,
  imports: [],
  templateUrl: './jersey.component.html',
  styleUrl: './jersey.component.css'
})
export class JerseyComponent {

}
