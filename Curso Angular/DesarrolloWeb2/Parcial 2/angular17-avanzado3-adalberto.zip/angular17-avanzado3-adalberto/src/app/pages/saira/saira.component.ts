import { Component } from '@angular/core';

@Component({
  selector: 'app-saira',
  standalone: true,
  imports: [],
  templateUrl: './saira.component.html',
  styleUrl: './saira.component.css'
})
export class SairaComponent {

}
