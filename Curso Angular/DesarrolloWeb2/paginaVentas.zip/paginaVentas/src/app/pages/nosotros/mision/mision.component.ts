import { Component } from '@angular/core';

@Component({
  selector: 'app-mision',
  standalone: true,
  imports: [],
  templateUrl: './mision.component.html',
  styleUrl: './mision.component.css'
})
export class MisionComponent {

}
