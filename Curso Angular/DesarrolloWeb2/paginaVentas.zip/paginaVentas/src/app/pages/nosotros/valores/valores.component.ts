import { Component } from '@angular/core';

@Component({
  selector: 'app-valores',
  standalone: true,
  imports: [],
  templateUrl: './valores.component.html',
  styleUrl: './valores.component.css'
})
export class ValoresComponent {

}
